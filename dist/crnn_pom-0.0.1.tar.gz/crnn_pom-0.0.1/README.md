# Convolutional Recurrent Neural Network - reimplements - Pytorch
This softwere is a reimplements of CRNN.
The model was implemented using PyTorch and einops. The training is a concise implementation using timm and Hugging Face's Accelerate.

## Usage

Train code sample
```
% python train.py -d ./data_lmdb_release/training/MJ/MJ_train/data.mdb
```

Inference code sample
```
% python predict.py -i sample.png
->available
```

## TODO
- test code 
- class document 
- predict code 

## Acknowledgements
This softwere was mostly base on https://github.com/meijieru/crnn.pytorch.